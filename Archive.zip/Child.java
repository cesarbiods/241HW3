/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package csc241hw03;

/**
 *
 * @author Cesar
 */
public class Child extends Guest{
    
    public Child(String l, String f) {
        super(l,f);
    }
    
}
